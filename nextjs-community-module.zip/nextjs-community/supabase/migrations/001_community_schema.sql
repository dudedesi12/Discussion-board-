-- IMMI-PINK COMMUNITY MODULE - Supabase Schema
-- Run in Supabase Dashboard > SQL Editor

-- 1. Community Profiles
CREATE TABLE IF NOT EXISTS public.community_profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  username TEXT UNIQUE NOT NULL, email TEXT, full_name TEXT, bio TEXT,
  location TEXT, avatar_url TEXT,
  role TEXT DEFAULT 'member' CHECK (role IN ('member','agent','admin')),
  visa_subclass TEXT, occupation_code TEXT, occupation_name TEXT, state TEXT,
  points_score INT, onshore BOOLEAN DEFAULT TRUE,
  agent_verified BOOLEAN DEFAULT FALSE, mara_number TEXT, specializations TEXT,
  availability_status TEXT DEFAULT 'offline' CHECK (availability_status IN ('available','busy','offline')),
  created_at TIMESTAMPTZ DEFAULT NOW(), last_seen TIMESTAMPTZ, is_active BOOLEAN DEFAULT TRUE
);

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS TRIGGER AS $$ BEGIN
  INSERT INTO public.community_profiles (id, username, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email,'@',1)), NEW.email);
  RETURN NEW;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 2. Posts
CREATE TABLE public.community_posts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  author_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL CHECK (char_length(title) >= 5 AND char_length(title) <= 300),
  body TEXT NOT NULL CHECK (char_length(body) >= 10),
  category TEXT NOT NULL CHECK (category IN ('visa-journey','state-nomination','points-help','skills-assessment','eoi-updates','agent-reviews','job-market','settlement','general')),
  tags TEXT[] DEFAULT '{}',
  like_count INT DEFAULT 0, reply_count INT DEFAULT 0, view_count INT DEFAULT 0,
  visa_subclass TEXT, state TEXT, occupation_code TEXT, points_score INT,
  is_anonymous BOOLEAN DEFAULT FALSE, is_resolved BOOLEAN DEFAULT FALSE, is_pinned BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Replies
CREATE TABLE public.community_replies (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID REFERENCES public.community_posts(id) ON DELETE CASCADE NOT NULL,
  author_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  body TEXT NOT NULL CHECK (char_length(body) >= 2),
  like_count INT DEFAULT 0, is_anonymous BOOLEAN DEFAULT FALSE, is_accepted BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Likes
CREATE TABLE public.community_likes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  post_id UUID REFERENCES public.community_posts(id) ON DELETE CASCADE,
  reply_id UUID REFERENCES public.community_replies(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  CHECK ((post_id IS NOT NULL AND reply_id IS NULL) OR (post_id IS NULL AND reply_id IS NOT NULL)),
  UNIQUE(user_id, post_id), UNIQUE(user_id, reply_id)
);

-- 5. Journey Milestones (THE KILLER FEATURE)
CREATE TABLE public.journey_milestones (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  visa_subclass TEXT NOT NULL CHECK (visa_subclass IN ('189','190','491','482','sid')),
  occupation_code TEXT NOT NULL, occupation_name TEXT, state TEXT,
  points_score INT, onshore BOOLEAN DEFAULT TRUE,
  eoi_submitted_at DATE, invitation_received_at DATE, visa_lodged_at DATE,
  s56_received_at DATE, s56_responded_at DATE, medicals_completed_at DATE, grant_received_at DATE,
  status TEXT DEFAULT 'eoi-submitted' CHECK (status IN ('eoi-submitted','invited','lodged','waiting','s56-received','granted','refused','withdrawn')),
  is_anonymous BOOLEAN DEFAULT TRUE, notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Agent Verification
CREATE TABLE public.agent_verifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  mara_number TEXT NOT NULL, issuing_authority TEXT DEFAULT 'OMARA',
  expiry_date DATE NOT NULL, document_url TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  reviewed_by UUID REFERENCES auth.users(id), reviewed_at TIMESTAMPTZ, rejection_reason TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Consultation Requests
CREATE TABLE public.consultation_requests (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  agent_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  topic TEXT NOT NULL, preferred_time TIMESTAMPTZ, message TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending','accepted','declined','completed')),
  created_at TIMESTAMPTZ DEFAULT NOW(), responded_at TIMESTAMPTZ
);

-- 8. Triggers for counter updates
CREATE OR REPLACE FUNCTION update_post_reply_count() RETURNS TRIGGER AS $$ BEGIN
  IF TG_OP = 'INSERT' THEN UPDATE community_posts SET reply_count = reply_count + 1 WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN UPDATE community_posts SET reply_count = GREATEST(reply_count - 1, 0) WHERE id = OLD.post_id; END IF;
  RETURN COALESCE(NEW, OLD);
END; $$ LANGUAGE plpgsql SECURITY DEFINER;
CREATE TRIGGER on_reply_change AFTER INSERT OR DELETE ON public.community_replies FOR EACH ROW EXECUTE FUNCTION update_post_reply_count();

CREATE OR REPLACE FUNCTION update_like_counts() RETURNS TRIGGER AS $$ BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.post_id IS NOT NULL THEN UPDATE community_posts SET like_count = like_count + 1 WHERE id = NEW.post_id;
    ELSIF NEW.reply_id IS NOT NULL THEN UPDATE community_replies SET like_count = like_count + 1 WHERE id = NEW.reply_id; END IF;
  ELSIF TG_OP = 'DELETE' THEN
    IF OLD.post_id IS NOT NULL THEN UPDATE community_posts SET like_count = GREATEST(like_count - 1, 0) WHERE id = OLD.post_id;
    ELSIF OLD.reply_id IS NOT NULL THEN UPDATE community_replies SET like_count = GREATEST(like_count - 1, 0) WHERE id = OLD.reply_id; END IF;
  END IF; RETURN COALESCE(NEW, OLD);
END; $$ LANGUAGE plpgsql SECURITY DEFINER;
CREATE TRIGGER on_like_change AFTER INSERT OR DELETE ON public.community_likes FOR EACH ROW EXECUTE FUNCTION update_like_counts();

-- 9. View count RPC
CREATE OR REPLACE FUNCTION increment_view_count(post_uuid UUID) RETURNS VOID AS $$
BEGIN UPDATE community_posts SET view_count = view_count + 1 WHERE id = post_uuid; END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 10. Processing stats view
CREATE OR REPLACE VIEW public.processing_stats AS
SELECT visa_subclass, occupation_code, occupation_name, state,
  COUNT(*) AS total_cases, COUNT(grant_received_at) AS total_grants,
  ROUND(AVG(CASE WHEN visa_lodged_at IS NOT NULL AND grant_received_at IS NOT NULL
    THEN EXTRACT(DAY FROM (grant_received_at::timestamp - visa_lodged_at::timestamp)) END))::INT AS avg_days_lodge_to_grant,
  ROUND(AVG(CASE WHEN eoi_submitted_at IS NOT NULL AND invitation_received_at IS NOT NULL
    THEN EXTRACT(DAY FROM (invitation_received_at::timestamp - eoi_submitted_at::timestamp)) END))::INT AS avg_days_eoi_to_invite,
  MIN(points_score) FILTER (WHERE grant_received_at IS NOT NULL) AS min_grant_points,
  ROUND(AVG(points_score) FILTER (WHERE grant_received_at IS NOT NULL))::INT AS avg_grant_points
FROM public.journey_milestones WHERE is_anonymous = TRUE
GROUP BY visa_subclass, occupation_code, occupation_name, state;

-- 11. Indexes
CREATE INDEX idx_posts_category ON public.community_posts(category);
CREATE INDEX idx_posts_created ON public.community_posts(created_at DESC);
CREATE INDEX idx_posts_author ON public.community_posts(author_id);
CREATE INDEX idx_replies_post ON public.community_replies(post_id);
CREATE INDEX idx_milestones_visa ON public.journey_milestones(visa_subclass);
CREATE INDEX idx_milestones_occ ON public.journey_milestones(occupation_code);
CREATE INDEX idx_milestones_state ON public.journey_milestones(state);

-- 12. Row Level Security
ALTER TABLE public.community_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.journey_milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agent_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.consultation_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Profiles viewable by all" ON public.community_profiles FOR SELECT USING (true);
CREATE POLICY "Users update own profile" ON public.community_profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Posts viewable by all" ON public.community_posts FOR SELECT USING (true);
CREATE POLICY "Auth users create posts" ON public.community_posts FOR INSERT WITH CHECK (auth.uid() = author_id);
CREATE POLICY "Authors update own posts" ON public.community_posts FOR UPDATE USING (auth.uid() = author_id);
CREATE POLICY "Authors delete own posts" ON public.community_posts FOR DELETE USING (auth.uid() = author_id);
CREATE POLICY "Replies viewable by all" ON public.community_replies FOR SELECT USING (true);
CREATE POLICY "Auth users create replies" ON public.community_replies FOR INSERT WITH CHECK (auth.uid() = author_id);
CREATE POLICY "Authors delete own replies" ON public.community_replies FOR DELETE USING (auth.uid() = author_id);
CREATE POLICY "Likes viewable by all" ON public.community_likes FOR SELECT USING (true);
CREATE POLICY "Auth users toggle likes" ON public.community_likes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users remove own likes" ON public.community_likes FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "Anon milestones viewable" ON public.journey_milestones FOR SELECT USING (is_anonymous = TRUE OR auth.uid() = user_id);
CREATE POLICY "Users create milestones" ON public.journey_milestones FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own milestones" ON public.journey_milestones FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users delete own milestones" ON public.journey_milestones FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "Agents see own verifications" ON public.agent_verifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Agents submit verification" ON public.agent_verifications FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users see own consultations" ON public.consultation_requests FOR SELECT USING (auth.uid() = student_id OR auth.uid() = agent_id);
CREATE POLICY "Students create requests" ON public.consultation_requests FOR INSERT WITH CHECK (auth.uid() = student_id);
CREATE POLICY "Agents respond to requests" ON public.consultation_requests FOR UPDATE USING (auth.uid() = agent_id);
